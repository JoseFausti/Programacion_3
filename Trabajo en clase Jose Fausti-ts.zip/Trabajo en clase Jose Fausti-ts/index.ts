// Ejercicio 1
class Coche {
    // Atributos
    private marca:string;
    private modelo:string;
    private velocidad:number;

    // Constructor
    constructor(marca:string, modelo:string, velocidad:number) {
        this.marca = marca;
        this.modelo = modelo;
        this.velocidad = velocidad;
    }
    
    // Getters y Setters
    public getMarca() : string {
        return this.marca;
    }
    public setMarca(marca : string) {
        this.marca = marca;
    }

    public getModelo() : string {
        return this.modelo;
    }
    public setModelo(modelo : string) {
        this.modelo = modelo;
    }
    
    public getVelocidad() : number {
        return this.velocidad;
    }
    public setVelocidad(velocidad : number) {
        this.velocidad = velocidad;
    }

    // Metodos
    public acelerar(vel:number): void{
        if (!isNaN(vel) && vel > 0) {
            this.velocidad += vel;
            console.log("La velocidad se ha incrementado en: ",vel,"km/h.");
        }else{
            console.log("Ingrese un valor válido mayor a 0.");  
        }
    }
    public frenar(vel:number): void{
        if (!isNaN(vel) && vel > 0) {
            this.velocidad -= vel ;
            if (this.velocidad < 0) {
                this.velocidad = 0;
            }
            console.log("La velocidad se ha decrementado en: ",vel,"km/h.");
        }else{
            console.log("Ingrese un valor válido mayor a 0.");  
        }
    }
    public mostrarEstado(): void{
        console.log(`
            marca: ${this.marca}\n
            modelo: ${this.modelo}\n
            velocidad: ${this.velocidad}
        `);
    }
}

const coche = new Coche("Nissan", "Sentra", 0);
coche.acelerar(20);
coche.frenar(10);
coche.mostrarEstado();

// Ejercicio 2
interface Idata{
   id:number;
   completed:boolean;
}
async function peticion_ej2 (){
    try {
        const peticion = await fetch("https://jsonplaceholder.typicode.com/todos");
        const data :Idata[] = await peticion.json();
        data.filter((e)=> e.completed);
        console.log("Tareas completadas:");
        console.log(data);
        
    } catch (error) {
        console.log(error);
    }

}
peticion_ej2();

// Ejercicio 3
